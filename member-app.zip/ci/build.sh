#!/bin/bash
# Builds the Shoalwater Bay app for iPhone on a GitHub Mac and sends it to App Store Connect (TestFlight).
set -euo pipefail
cd "$(dirname "$0")/.."                      # always run from the folder that holds project.yml
source ci/config.env
export BUNDLE_ID APP_VERSION="${APP_VERSION:-1.0}" BUILD_NUMBER="${BUILD_NUMBER:-1}" APPLE_TEAM_ID="${APPLE_TEAM_ID:-}"
RUNNER_TEMP="${RUNNER_TEMP:-$(mktemp -d)}"

ok=1
[ -f App/Assets.xcassets/AppIcon.appiconset/AppIcon.png ] || { echo "::error::The app icon is missing from member-app.zip"; ok=0; }
[ -n "${BUNDLE_ID:-}" ] || { echo "::error::BUNDLE_ID is missing from ci/config.env"; ok=0; }
[ -n "${APPLE_TEAM_ID}" ] || { echo "::error::Secret APPLE_TEAM_ID is not set"; ok=0; }
[ -n "${ASC_KEY_ID:-}" ] || { echo "::error::Secret ASC_KEY_ID is not set"; ok=0; }
[ -n "${ASC_ISSUER_ID:-}" ] || { echo "::error::Secret ASC_ISSUER_ID is not set"; ok=0; }
[ -n "${ASC_KEY_P8:-}" ] || { echo "::error::Secret ASC_KEY_P8 is not set"; ok=0; }
[[ "${BUILD_NUMBER}" =~ ^[0-9]+(\.[0-9]+){0,2}$ ]] || { echo "::error::BUILD_NUMBER must be a number such as 7 (it is '${BUILD_NUMBER}')"; ok=0; }
[[ "${APP_VERSION}" =~ ^[0-9]+(\.[0-9]+){0,2}$ ]] || { echo "::error::APP_VERSION must look like 1.0 or 1.0.1 (it is '${APP_VERSION}')"; ok=0; }
[ "$ok" = 1 ] || exit 1

report() {   # print the useful lines of a log as GitHub error notes, then the tail
  grep -E "error:|Error Domain|error |No profiles|requires a provisioning|No Account|Invalid|not found|already been used|bundle identifier|nearly matches|does not conform" "$1" | sort -u | head -n 25 | while IFS= read -r line; do echo "::error::${line:0:900}"; done || true
  echo "---- last lines of $1 ----"; tail -n 60 "$1" || true
}

hints() {    # plain-language causes for the sign/upload failures seen most often
  local log="$1"
  if grep -qiE "No suitable application records|Cannot determine the Apple ID|could not find.*app.*bundle" "$log"; then
    echo "::error::App Store Connect has no app with the bundle ID ${BUNDLE_ID} yet. In App Store Connect choose Apps, +, New App, and pick this bundle ID, then run the build again."; fi
  if grep -qiE "cloud.managed|Cloud signing permission|not permitted|forbidden|does not have permission" "$log"; then
    echo "::error::The App Store Connect API key is not allowed to sign. Make a team key with the Admin role (Users and Access, Integrations, App Store Connect API) and update the ASC_KEY_ID and ASC_KEY_P8 secrets."; fi
  if grep -qiE "identifier.*not available|cannot be registered|Failed to register bundle identifier" "$log"; then
    echo "::error::The bundle ID ${BUNDLE_ID} could not be registered to this team. Register it by hand at developer.apple.com (Certificates, IDs and Profiles, Identifiers, +, App IDs), or change BUNDLE_ID in ci/config.env if Apple says it is taken."; fi
  if grep -qiE "Authentication credentials are missing or invalid|NOT_AUTHORIZED|status code: 401|invalid.*(issuer|key)" "$log"; then
    echo "::error::Apple did not accept the API key. Check that ASC_KEY_ID, ASC_ISSUER_ID and ASC_KEY_P8 all belong to the same key and that ASC_KEY_P8 is the whole .p8 file, first and last lines included."; fi
  if grep -qiE "bundle version must be higher|already been used|Redundant Binary" "$log"; then
    echo "::error::This build number (${BUILD_NUMBER}) was already uploaded for version ${APP_VERSION}. Run the build again; each run must use a higher build number."; fi
  if grep -qiE "agreement.*(accept|review|expired|updated)|PLA Update" "$log"; then
    echo "::error::Apple needs an agreement accepted. Sign in at developer.apple.com/account and at App Store Connect (Business), accept what is pending, then run the build again."; fi
}

echo "== Xcode =="; xcodebuild -version
echo "== Tools =="
if ! command -v xcodegen >/dev/null 2>&1; then
  HOMEBREW_NO_AUTO_UPDATE=1 HOMEBREW_NO_INSTALL_CLEANUP=1 HOMEBREW_NO_ENV_HINTS=1 brew install xcodegen \
    || { echo "::error::Could not install XcodeGen with Homebrew. Run the build again; if it keeps failing, GitHub's Mac image changed."; exit 1; }
fi
xcodegen --version || true
echo "== Project =="
xcodegen generate || { echo "::error::XcodeGen could not make the Xcode project from project.yml."; exit 1; }
[ -f App/Info.plist ] || { echo "::error::XcodeGen did not write App/Info.plist."; exit 1; }
plutil -lint App/Info.plist App/PrivacyInfo.xcprivacy

KEY="$HOME/private_keys/AuthKey_${ASC_KEY_ID}.p8"
mkdir -p "$HOME/private_keys"; printf '%s\n' "$ASC_KEY_P8" > "$KEY"; chmod 600 "$KEY"
trap 'rm -rf "$HOME/private_keys"' EXIT
grep -q "BEGIN PRIVATE KEY" "$KEY" || { echo "::error::Secret ASC_KEY_P8 does not look like a .p8 key file. Paste the whole file, including the BEGIN and END lines."; exit 1; }
AUTH=(-allowProvisioningUpdates -authenticationKeyPath "$KEY" -authenticationKeyID "$ASC_KEY_ID" -authenticationKeyIssuerID "$ASC_ISSUER_ID")

cat > "$RUNNER_TEMP/ExportOptions.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>method</key><string>app-store-connect</string>
	<key>destination</key><string>upload</string>
	<key>teamID</key><string>${APPLE_TEAM_ID}</string>
	<key>signingStyle</key><string>automatic</string>
	<key>manageAppVersionAndBuildNumber</key><false/>
	<key>uploadSymbols</key><true/>
</dict>
</plist>
PLIST

ARCHIVE="$RUNNER_TEMP/ShoalwaterBay.xcarchive"
echo "== Build =="
# Built without a development signature (a new account has no test devices). The App Store signature is added in the next step.
if ! xcodebuild archive -project ShoalwaterBay.xcodeproj -scheme ShoalwaterBay -configuration Release \
  -destination 'generic/platform=iOS' -archivePath "$ARCHIVE" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" > "$RUNNER_TEMP/build.log" 2>&1; then
  echo "::error::The app did not build."; report "$RUNNER_TEMP/build.log"; exit 1; fi
tail -n 3 "$RUNNER_TEMP/build.log"
# Show compiler warnings in the run summary. "nearly matches" means Apple changed a method's shape and the app
# would silently skip that method, so that one stops the build.
grep -E "\.swift:[0-9]+:[0-9]+: warning:" "$RUNNER_TEMP/build.log" | sort -u | head -n 20 | while IFS= read -r line; do echo "::warning::${line:0:900}"; done || true
# Only a real compiler warning line for one of the app's own Swift files counts (file.swift:line:col: warning: ...).
if grep -qE "/App/[A-Za-z]+\.swift:[0-9]+:[0-9]+: warning: .*nearly matches" "$RUNNER_TEMP/build.log"; then
  echo "::error::A method in the app no longer matches Apple's current definition (see the 'nearly matches' warning above). The app would misbehave, so the build was stopped."; exit 1; fi

echo "== Check the built app =="
# Only a missing app stops the build here. The other checks are notes: a mistake in a check must not
# throw away a good build, and Apple's upload step does its own checking afterwards.
APP="$ARCHIVE/Products/Applications/ShoalwaterBay.app"
pb() { /usr/libexec/PlistBuddy -c "Print :$1" "$APP/Info.plist" 2>/dev/null || true; }
[ -d "$APP" ] || { echo "::error::The build finished but ShoalwaterBay.app is not in the archive."; ls -R "$ARCHIVE/Products" 2>/dev/null | head -n 20 || true; exit 1; }
[ -f "$APP/PrivacyInfo.xcprivacy" ] || echo "::warning::PrivacyInfo.xcprivacy was not found in the built app. Apple may email about a missing privacy manifest."
[ -f "$APP/Assets.car" ] || echo "::warning::Assets.car (app icon and launch colour) was not found in the built app."
[ "$(pb CFBundleIdentifier)" = "$BUNDLE_ID" ] || echo "::warning::The built app's bundle ID reads '$(pb CFBundleIdentifier)', expected '$BUNDLE_ID'."
[ "$(pb CFBundleShortVersionString)" = "$APP_VERSION" ] || echo "::warning::The built app's version reads '$(pb CFBundleShortVersionString)', expected '$APP_VERSION'."
[ "$(pb CFBundleVersion)" = "$BUILD_NUMBER" ] || echo "::warning::The built app's build number reads '$(pb CFBundleVersion)', expected '$BUILD_NUMBER'."
[ "$(pb WKAppBoundDomains:0)" = "shoalwaterbaytribe.org" ] || echo "::warning::Could not confirm WKAppBoundDomains in the built app's Info.plist. Without it the app would show a blank screen."
[ -n "$(pb CFBundleIcons:CFBundlePrimaryIcon:CFBundleIconName)" ] || echo "::warning::Could not confirm the app icon in the built app (CFBundleIconName). If Apple rejects the upload for a missing icon, this is why."
echo "Bundle ID $(pb CFBundleIdentifier), version $(pb CFBundleShortVersionString) ($(pb CFBundleVersion))"

echo "== Sign and upload =="
if ! xcodebuild -exportArchive -archivePath "$ARCHIVE" \
  -exportOptionsPlist "$RUNNER_TEMP/ExportOptions.plist" -exportPath "$RUNNER_TEMP/export" "${AUTH[@]}" > "$RUNNER_TEMP/export.log" 2>&1; then
  echo "::error::Signing or upload failed."; report "$RUNNER_TEMP/export.log"
  for f in "$RUNNER_TEMP"/export/*.log /var/folders/*/*/T/*.xcdistributionlogs/IDEDistribution.standard.log; do
    if [ -f "$f" ]; then echo "---- $f ----"; tail -n 40 "$f"; cat "$f" >> "$RUNNER_TEMP/export.log"; fi
  done
  hints "$RUNNER_TEMP/export.log"
  exit 1; fi
tail -n 5 "$RUNNER_TEMP/export.log"
echo "::notice::Uploaded. The build will appear in App Store Connect under TestFlight in a few minutes."

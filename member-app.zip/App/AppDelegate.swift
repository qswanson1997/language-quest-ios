import UIKit

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        return true
    }

    func application(_ application: UIApplication,
                     configurationForConnecting connectingSceneSession: UISceneSession,
                     options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        let configuration = UISceneConfiguration(name: "Default", sessionRole: connectingSceneSession.role)
        configuration.delegateClass = SceneDelegate.self      // set here too, so it never depends on the Info.plist text
        return configuration
    }
}

final class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    /// The screens the Home-screen quick actions can open (see UIApplicationShortcutItems in Info.plist).
    private static let shortcutSections: Set<String> = ["emergency", "events", "directory"]

    private static func url(for shortcutItem: UIApplicationShortcutItem) -> URL? {
        guard shortcutSections.contains(shortcutItem.type) else { return nil }
        return URL(string: "https://shoalwaterbaytribe.org/app/#" + shortcutItem.type)
    }

    private var appViewController: AppViewController? {
        return window?.rootViewController as? AppViewController
    }

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }
        let root = AppViewController()
        if let item = connectionOptions.shortcutItem, let url = SceneDelegate.url(for: item) {
            root.startURL = url                               // the app was opened from a quick action
        }
        let window = UIWindow(windowScene: windowScene)
        window.rootViewController = root
        window.makeKeyAndVisible()
        self.window = window
    }

    func windowScene(_ windowScene: UIWindowScene, performActionFor shortcutItem: UIApplicationShortcutItem,
                     completionHandler: @escaping (Bool) -> Void) {
        guard let url = SceneDelegate.url(for: shortcutItem), let app = appViewController else {
            completionHandler(false)
            return
        }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        app.open(section: url)
        completionHandler(true)
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        appViewController?.wentToBack()
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
        appViewController?.cameToFront()
    }
}

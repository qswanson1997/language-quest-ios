import UIKit
import WebKit
import SafariServices
import QuickLook

/// Shows the Tribe's app (https://shoalwaterbaytribe.org/app/) full screen.
/// Everything the app shows comes live from the Tribe's website, so the app
/// never needs an App Store update when the website's content changes.
///
/// The WebKit delegate methods that hand back a decision use the `async` form on purpose:
/// the completion-handler forms changed their attributes in recent SDKs, and a method that
/// only "nearly matches" is silently never called.
final class AppViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate, QLPreviewControllerDataSource {

    private let siteHost = "shoalwaterbaytribe.org"
    private let homeURL = URL(string: "https://shoalwaterbaytribe.org/app/")!
    private let mainLine = "+13602676766"          // Tribal Center main line, shown only on the no-connection screen
    private let navy = UIColor(red: 15.0 / 255.0, green: 49.0 / 255.0, blue: 68.0 / 255.0, alpha: 1)

    /// WordPress.com sign-in pages the website may pass through. They load inside the app so the
    /// sign-in ends up in the app's own cookie store. Each one is covered by WKAppBoundDomains.
    private let signInHosts: Set<String> = ["public-api.wordpress.com", "r-login.wordpress.com", "jetpack.wordpress.com"]
    /// Links that iPhone apps (Phone, Mail, Messages, Maps, App Store) should handle.
    private let systemSchemes: Set<String> = ["tel", "telprompt", "mailto", "sms", "facetime", "facetime-audio", "maps", "itms-apps"]
    private let fileExtensions: Set<String> = ["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "csv", "zip", "ics", "vcf"]
    /// After this long in the background the web app is reloaded from scratch when the app comes back.
    private let staleAfter: TimeInterval = 4 * 60 * 60

    /// Set before the screen first appears to open a section (a Home-screen quick action) instead of the home screen.
    var startURL: URL?

    private var webView: WKWebView!
    private var offlineView: UIView?
    private var backButton: UIButton!
    private var hasShownApp = false
    private var leftAt: Date?
    private var needsReload = false
    private var downloadFiles: [WKDownload: URL] = [:]
    private var previewFile: URL?

    override var preferredStatusBarStyle: UIStatusBarStyle { return .lightContent }

    private var downloadsFolder: URL {
        return FileManager.default.temporaryDirectory.appendingPathComponent("downloads", isDirectory: true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = navy
        try? FileManager.default.removeItem(at: downloadsFolder)      // files opened last time

        let config = WKWebViewConfiguration()
        // App-bound mode is what makes the web app's offline copy (its service worker) work inside an app.
        // The domains are listed under WKAppBoundDomains in Info.plist; the web view can only go to those,
        // so every other link is opened outside the web view before WebKit tries it (see the policy method).
        config.limitsNavigationsToAppBoundDomains = true
        config.websiteDataStore = WKWebsiteDataStore.default()           // on disk: sign-ins survive closing the app
        config.allowsInlineMediaPlayback = true
        config.applicationNameForUserAgent = "ShoalwaterApp/1.0"
        // Tell the web app it is already installed, so it does not offer "add to home screen".
        let flag = "try{Object.defineProperty(navigator,'standalone',{get:function(){return true}})}catch(e){}"
        config.userContentController.addUserScript(WKUserScript(source: flag, injectionTime: .atDocumentStart, forMainFrameOnly: true))

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = navy
        webView.scrollView.backgroundColor = navy
        webView.scrollView.contentInsetAdjustmentBehavior = .never     // the web page handles the notch itself (viewport-fit=cover)
        webView.allowsBackForwardNavigationGestures = false
        webView.allowsLinkPreview = false
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        // Shown only if a link takes the main screen to a page outside the app (a website page or a sign-in page).
        backButton = UIButton(type: .system)
        backButton.setTitle("  Back to the app  ", for: .normal)
        backButton.titleLabel?.font = UIFont.preferredFont(forTextStyle: .headline)
        backButton.titleLabel?.adjustsFontForContentSizeCategory = true
        backButton.setTitleColor(.white, for: .normal)
        backButton.backgroundColor = navy
        backButton.layer.cornerRadius = 22
        backButton.layer.borderWidth = 1
        backButton.layer.borderColor = UIColor.white.withAlphaComponent(0.6).cgColor
        backButton.isHidden = true
        backButton.translatesAutoresizingMaskIntoConstraints = false
        backButton.addTarget(self, action: #selector(goHome), for: .touchUpInside)
        view.addSubview(backButton)
        NSLayoutConstraint.activate([
            backButton.heightAnchor.constraint(greaterThanOrEqualToConstant: 44),
            backButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            backButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -12)
        ])

        load(startURL ?? homeURL)
        startURL = nil
    }

    // MARK: - Coming and going

    func wentToBack() {
        leftAt = Date()
    }

    func cameToFront() {
        guard isViewLoaded else { return }
        let wasAway = leftAt != nil                // false the first time, right after launch
        let away = leftAt.map { Date().timeIntervalSince($0) } ?? 0
        leftAt = nil
        if offlineView != nil || needsReload || (wasAway && webView.url == nil && !webView.isLoading) {
            needsReload = false
            loadHome()
            return
        }
        guard isInApp(webView.url) else { return }
        if away > staleAfter {
            webView.reload()                 // a long time away: start fresh (also picks up a newer web app)
        } else if away > 30 {
            // The web app refreshes its information when it becomes visible. WebKit normally tells it;
            // this makes sure of it. An extra notice only causes one extra refresh.
            webView.evaluateJavaScript("try{document.dispatchEvent(new Event('visibilitychange'));window.dispatchEvent(new Event('focus'))}catch(e){}", completionHandler: nil)
        }
    }

    /// Opens a section of the app (from a Home-screen quick action), for example .../app/#events.
    func open(section url: URL) {
        guard isViewLoaded else { startURL = url; return }
        if let shown = presentedViewController, !(shown is UIAlertController) {
            shown.dismiss(animated: false)
        }
        let fragment = url.fragment ?? ""
        let isPlainWord = !fragment.isEmpty && fragment.allSatisfy { $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "-") }
        if offlineView == nil && isInApp(webView.url) && !webView.isLoading && isPlainWord {
            // Already in the app: change the section without reloading the page.
            let script = "(function(h){if(location.hash===h){window.dispatchEvent(new HashChangeEvent('hashchange'))}else{location.hash=h}})('#\(fragment)')"
            webView.evaluateJavaScript(script, completionHandler: nil)
        } else {
            load(url)
        }
    }

    @objc private func goHome() { loadHome() }

    private func loadHome() { load(homeURL) }

    private func load(_ url: URL) {
        webView.load(URLRequest(url: url, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 20))
    }

    // MARK: - Where links go

    private func isOurSite(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        return host == siteHost || host == "www." + siteHost
    }

    private func isInApp(_ url: URL?) -> Bool {
        guard let url = url, isOurSite(url) else { return false }
        return url.path == "/app" || url.path.hasPrefix("/app/")
    }

    private func isSignIn(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        if signInHosts.contains(host) { return true }
        return host == "wordpress.com" && (url.path.hasPrefix("/log-in") || url.path == "/wp-login.php")
    }

    private func isFileLink(_ url: URL) -> Bool {
        if fileExtensions.contains(url.pathExtension.lowercased()) { return true }
        let query = (url.query ?? "").lowercased()
        return query.contains("tbm_ics=") || query.contains("tbm_vcard=")
    }

    private func openInSystem(_ url: URL) {
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }

    /// Other websites open in a Safari sheet on top of the app, so "Done" always comes back to the app.
    private func openOutside(_ url: URL) {
        let scheme = (url.scheme ?? "").lowercased()
        guard scheme == "http" || scheme == "https" else { return }
        if url.host?.lowercased() == "maps.apple.com" { openInSystem(url); return }      // straight to the Maps app
        guard presentedViewController == nil else { openInSystem(url); return }
        let safari = SFSafariViewController(url: url)
        safari.preferredBarTintColor = navy
        safari.preferredControlTintColor = .white
        present(safari, animated: true)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction) async -> WKNavigationActionPolicy {
        guard let url = navigationAction.request.url else { return .allow }
        let scheme = (url.scheme ?? "").lowercased()

        if scheme == "about" || scheme == "blob" || scheme == "data" {
            return navigationAction.shouldPerformDownload ? .download : .allow
        }
        if scheme != "http" && scheme != "https" {           // tel:, mailto:, sms:, maps: — from the page or from inside the portal frame
            if systemSchemes.contains(scheme) { openInSystem(url) }
            return .cancel
        }

        let ours = isOurSite(url)
        if ours && (navigationAction.shouldPerformDownload || isFileLink(url)) {
            return .download                                  // fetched with the member's sign-in, then shown over the app
        }
        guard let target = navigationAction.targetFrame else {     // a link that asks for a new window
            if ours || isSignIn(url) { webView.load(navigationAction.request) } else { openOutside(url) }
            return .cancel
        }
        if target.isMainFrame {
            if ours || isSignIn(url) { return .allow }
            openOutside(url)                                  // never let WebKit try a domain outside WKAppBoundDomains
            return .cancel
        }
        // Inside a frame (the Member Portal): a tapped link to another website opens outside; embedded content loads normally.
        if !ours && navigationAction.navigationType == .linkActivated {
            openOutside(url)
            return .cancel
        }
        return .allow
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse) async -> WKNavigationResponsePolicy {
        let response = navigationResponse.response
        guard let url = response.url else { return .allow }
        let scheme = (url.scheme ?? "").lowercased()
        guard scheme == "http" || scheme == "https" else { return .allow }

        let mime = (response.mimeType ?? "").lowercased()
        let disposition = ((response as? HTTPURLResponse)?.value(forHTTPHeaderField: "Content-Disposition") ?? "").lowercased()
        let isFile = disposition.hasPrefix("attachment")
            || mime.contains("calendar") || mime.contains("vcard")
            || !navigationResponse.canShowMIMEType
            || (navigationResponse.isForMainFrame && mime == "application/pdf")
        guard isFile else { return .allow }

        if isOurSite(url) { return .download }
        if navigationResponse.isForMainFrame {
            openOutside(url)
            return .cancel
        }
        return .allow
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        // window.open(): the policy method above normally deals with it first; this is the safety net.
        if let url = navigationAction.request.url {
            if isOurSite(url) || isSignIn(url) { webView.load(navigationAction.request) } else { openOutside(url) }
        }
        return nil
    }

    // MARK: - Files (PDF, Word, calendar invitations, contact cards)

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = self
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String) async -> URL? {
        var name = (suggestedFilename as NSString).lastPathComponent
        if name.isEmpty || name == "." || name == ".." { name = "file" }
        let folder = downloadsFolder.appendingPathComponent(UUID().uuidString, isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: nil)
        } catch {
            return nil
        }
        let file = folder.appendingPathComponent(name)
        downloadFiles[download] = file
        return file
    }

    func downloadDidFinish(_ download: WKDownload) {
        guard let file = downloadFiles.removeValue(forKey: download) else { return }
        show(file: file)
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        downloadFiles[download] = nil
        if (error as NSError).code == NSURLErrorCancelled { return }
        guard presentedViewController == nil else { return }
        let alert = UIAlertController(title: "Could not open the file", message: "Check your connection and try again.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true)
    }

    private func show(file: URL) {
        guard presentedViewController == nil else { return }
        if QLPreviewController.canPreview(file as NSURL) {
            previewFile = file
            let preview = QLPreviewController()
            preview.dataSource = self
            present(preview, animated: true)
        } else {
            let share = UIActivityViewController(activityItems: [file], applicationActivities: nil)
            share.popoverPresentationController?.sourceView = view
            share.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
            present(share, animated: true)
        }
    }

    func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
        return previewFile == nil ? 0 : 1
    }

    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        return (previewFile ?? downloadsFolder) as NSURL
    }

    // MARK: - Loading, and what to show with no connection

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        hideOffline()
        let inApp = isInApp(webView.url)
        if inApp { hasShownApp = true }
        backButton.isHidden = inApp
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        handle(error)
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        handle(error)
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        // iOS closed the web page to free memory. Bring it back now if the app is on screen, otherwise when it returns.
        hasShownApp = false
        if view.window?.windowScene?.activationState == .foregroundActive {
            loadHome()
        } else {
            needsReload = true
        }
    }

    private func handle(_ error: Error) {
        let ns = error as NSError
        if ns.domain == NSURLErrorDomain && ns.code == NSURLErrorCancelled { return }
        if ns.domain == "WebKitErrorDomain" && (ns.code == 102 || ns.code == 204) { return }   // we cancelled it on purpose, or it became a file
        if ns.domain == "WKErrorDomain" && ns.code == WKError.Code.navigationAppBoundDomain.rawValue {
            // A page tried to send the main screen to a domain outside WKAppBoundDomains. Open it outside instead.
            if let url = ns.userInfo[NSURLErrorFailingURLErrorKey] as? URL { openOutside(url) }
            return
        }
        if hasShownApp && isInApp(webView.url) { return }     // the app is on screen; it shows its own notice
        showOffline()
    }

    private func hideOffline() {
        offlineView?.removeFromSuperview()
        offlineView = nil
    }

    private func bigButton(_ title: String, color: UIColor, textColor: UIColor, action: Selector) -> UIButton {
        var style = UIButton.Configuration.filled()
        style.title = title
        style.titleAlignment = .center
        style.baseBackgroundColor = color
        style.baseForegroundColor = textColor
        style.cornerStyle = .large
        style.contentInsets = NSDirectionalEdgeInsets(top: 16, leading: 16, bottom: 16, trailing: 16)
        style.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { incoming in
            var outgoing = incoming
            outgoing.font = UIFont.preferredFont(forTextStyle: .headline)
            return outgoing
        }
        let button = UIButton(configuration: style, primaryAction: nil)
        button.heightAnchor.constraint(greaterThanOrEqualToConstant: 56).isActive = true
        button.addTarget(self, action: action, for: .touchUpInside)
        return button
    }

    private func showOffline() {
        if offlineView != nil { return }
        let cover = UIView()
        cover.backgroundColor = navy
        cover.translatesAutoresizingMaskIntoConstraints = false

        let title = UILabel()
        title.text = "No connection"
        title.font = UIFont.preferredFont(forTextStyle: .title1)
        title.adjustsFontForContentSizeCategory = true
        title.textColor = .white
        title.textAlignment = .center
        title.numberOfLines = 0
        title.accessibilityTraits = .header

        let body = UILabel()
        body.text = "The app could not reach the Tribe's website. Check your signal or Wi-Fi and try again."
        body.font = UIFont.preferredFont(forTextStyle: .body)
        body.adjustsFontForContentSizeCategory = true
        body.textColor = UIColor.white.withAlphaComponent(0.85)
        body.numberOfLines = 0
        body.textAlignment = .center

        let retry = bigButton("Try again", color: .white, textColor: navy, action: #selector(goHome))
        let call911 = bigButton("Emergency: call 911", color: UIColor(red: 0.78, green: 0.22, blue: 0.18, alpha: 1), textColor: .white, action: #selector(call911Tapped))
        let callOffice = bigButton("Call the Tribal Center (360) 267-6766", color: UIColor.white.withAlphaComponent(0.14), textColor: .white, action: #selector(callOfficeTapped))

        let stack = UIStackView(arrangedSubviews: [title, body, retry, call911, callOffice])
        stack.axis = .vertical
        stack.spacing = 16
        stack.setCustomSpacing(28, after: body)
        stack.translatesAutoresizingMaskIntoConstraints = false

        // In a scroll view so nothing is cut off with very large text sizes; centred when it all fits.
        let scroll = UIScrollView()
        scroll.alwaysBounceVertical = false
        scroll.translatesAutoresizingMaskIntoConstraints = false
        let content = UIView()
        content.translatesAutoresizingMaskIntoConstraints = false
        content.addSubview(stack)
        scroll.addSubview(content)
        cover.addSubview(scroll)
        view.insertSubview(cover, belowSubview: backButton)
        let fitHeight = content.heightAnchor.constraint(equalTo: scroll.frameLayoutGuide.heightAnchor)
        fitHeight.priority = .defaultLow           // exactly one screen tall unless the text needs more
        NSLayoutConstraint.activate([
            cover.topAnchor.constraint(equalTo: view.topAnchor),
            cover.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            cover.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            cover.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            scroll.topAnchor.constraint(equalTo: cover.safeAreaLayoutGuide.topAnchor),
            scroll.bottomAnchor.constraint(equalTo: cover.safeAreaLayoutGuide.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: cover.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: cover.trailingAnchor),

            content.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor),
            content.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor),
            content.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor),
            content.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor),
            content.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor),
            content.heightAnchor.constraint(greaterThanOrEqualTo: scroll.frameLayoutGuide.heightAnchor),
            fitHeight,

            stack.centerYAnchor.constraint(equalTo: content.centerYAnchor),
            stack.topAnchor.constraint(greaterThanOrEqualTo: content.topAnchor, constant: 24),
            stack.bottomAnchor.constraint(lessThanOrEqualTo: content.bottomAnchor, constant: -24),
            stack.leadingAnchor.constraint(equalTo: content.leadingAnchor, constant: 28),
            stack.trailingAnchor.constraint(equalTo: content.trailingAnchor, constant: -28)
        ])
        backButton.isHidden = true
        offlineView = cover
        UIAccessibility.post(notification: .screenChanged, argument: title)
    }

    @objc private func call911Tapped() {
        if let url = URL(string: "tel:911") { openInSystem(url) }
    }

    @objc private func callOfficeTapped() {
        if let url = URL(string: "tel:" + mainLine) { openInSystem(url) }
    }

    // MARK: - Website pop-up messages (used by some forms)

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo) async {
        guard presentedViewController == nil else { return }
        await withCheckedContinuation { (finished: CheckedContinuation<Void, Never>) in
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in finished.resume() })
            self.present(alert, animated: true)
        }
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo) async -> Bool {
        guard presentedViewController == nil else { return false }
        return await withCheckedContinuation { (finished: CheckedContinuation<Bool, Never>) in
            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in finished.resume(returning: false) })
            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in finished.resume(returning: true) })
            self.present(alert, animated: true)
        }
    }
}

#!/bin/bash
# Builds Language Quest for iPhone on a GitHub Mac and sends it to App Store Connect (TestFlight).
set -euo pipefail
source ci/config.env
export BUNDLE_ID APP_VERSION="${APP_VERSION:-1.0}" BUILD_NUMBER="${BUILD_NUMBER:-1}" APPLE_TEAM_ID="${APPLE_TEAM_ID:-}"

ok=1
[ -f App/web/index.html ] || { echo "::error::The game file is missing from project.zip (App/web/index.html)"; ok=0; }
[ -n "${APPLE_TEAM_ID}" ] || { echo "::error::Secret APPLE_TEAM_ID is not set"; ok=0; }
[ -n "${ASC_KEY_ID:-}" ] || { echo "::error::Secret ASC_KEY_ID is not set"; ok=0; }
[ -n "${ASC_ISSUER_ID:-}" ] || { echo "::error::Secret ASC_ISSUER_ID is not set"; ok=0; }
[ -n "${ASC_KEY_P8:-}" ] || { echo "::error::Secret ASC_KEY_P8 is not set"; ok=0; }
[ "$ok" = 1 ] || exit 1

echo "== Xcode =="; xcodebuild -version
echo "== Fonts =="; python3 tools/embed_fonts.py App/web/index.html
echo "== Tools =="; brew install xcodegen librsvg
echo "== Icon =="
rsvg-convert -w 1024 -h 1024 icon.svg -o "$RUNNER_TEMP/icon.png"
sips -s format jpeg -s formatOptions 100 "$RUNNER_TEMP/icon.png" --out "$RUNNER_TEMP/icon.jpg"
sips -s format png "$RUNNER_TEMP/icon.jpg" --out App/Assets.xcassets/AppIcon.appiconset/AppIcon.png
echo "== Project =="; xcodegen generate

KEY="$HOME/private_keys/AuthKey_${ASC_KEY_ID}.p8"
mkdir -p "$HOME/private_keys"; printf '%s\n' "$ASC_KEY_P8" > "$KEY"
trap 'rm -rf "$HOME/private_keys"' EXIT
AUTH=(-allowProvisioningUpdates -authenticationKeyPath "$KEY" -authenticationKeyID "$ASC_KEY_ID" -authenticationKeyIssuerID "$ASC_ISSUER_ID")

# Show the important error lines where they are easy to find (the run's summary page) if a step fails.
report() { echo "---- last lines of the log ----"; tail -n 60 "$1" || true
  grep -E "error:|Error Domain|No profiles|No signing certificate|requires a provisioning profile|is not registered|Invalid|ITMS-|forbidden|not have permission|Authentication" "$1" | sed 's/^[[:space:]]*//' | awk '!seen[$0]++' | head -n 10 | while IFS= read -r l; do echo "::error::${l:0:400}"; done; }

cat > "$RUNNER_TEMP/ExportOptions.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>method</key><string>app-store-connect</string>
  <key>destination</key><string>upload</string>
  <key>signingStyle</key><string>automatic</string>
  <key>teamID</key><string>${APPLE_TEAM_ID}</string>
  <key>manageAppVersionAndBuildNumber</key><false/>
  <key>uploadSymbols</key><true/>
</dict></plist>
PLIST

echo "== Build =="
# Built without signing: an account with no registered test devices cannot make a development profile.
# The App Store signature is added in the next step.
if ! xcodebuild archive -project LanguageQuest.xcodeproj -scheme LanguageQuest -configuration Release \
  -destination 'generic/platform=iOS' -archivePath "$RUNNER_TEMP/LanguageQuest.xcarchive" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" > "$RUNNER_TEMP/build.log" 2>&1; then
  echo "::error::The app did not build."; report "$RUNNER_TEMP/build.log"; exit 1; fi
tail -n 3 "$RUNNER_TEMP/build.log"

echo "== Sign and upload =="
if ! xcodebuild -exportArchive -archivePath "$RUNNER_TEMP/LanguageQuest.xcarchive" \
  -exportOptionsPlist "$RUNNER_TEMP/ExportOptions.plist" -exportPath "$RUNNER_TEMP/export" "${AUTH[@]}" > "$RUNNER_TEMP/export.log" 2>&1; then
  echo "::error::Signing or upload failed."; report "$RUNNER_TEMP/export.log"
  for f in "$RUNNER_TEMP"/export/*.log /var/folders/*/*/T/*.xcdistributionlogs/IDEDistribution.standard.log; do [ -f "$f" ] && { echo "---- $f ----"; tail -n 40 "$f"; } || true; done
  exit 1; fi
tail -n 5 "$RUNNER_TEMP/export.log"
echo "::notice::Uploaded. The build will appear in App Store Connect under TestFlight in a few minutes."

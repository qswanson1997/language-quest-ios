#!/bin/bash
# Builds Language Quest for iPhone on a GitHub Mac and sends it to App Store Connect (TestFlight).
set -euo pipefail
source ci/config.env
export BUNDLE_ID APP_VERSION="${APP_VERSION:-1.0}" BUILD_NUMBER="${BUILD_NUMBER:-1}" APPLE_TEAM_ID="${APPLE_TEAM_ID:-}"

ok=1
[ -f App/web/index.html ] || { echo "::error::The game file is missing from project.zip (App/web/index.html)"; ok=0; }
[ -n "${APPLE_TEAM_ID}" ] || { echo "::error::Secret APPLE_TEAM_ID is not set"; ok=0; }
[ -n "${ASC_KEY_ID:-}" ] || { echo "::error::Secret ASC_KEY_ID is not set"; ok=0; }
[ -n "${ASC_ISSUER_ID:-}" ] || { echo "::error::Secret ASC_ISSUER_ID is not set"; ok=0; }
[ -n "${ASC_KEY_P8:-}" ] || { echo "::error::Secret ASC_KEY_P8 is not set"; ok=0; }
[ "$ok" = 1 ] || exit 1

echo "== Xcode =="; xcodebuild -version
echo "== Fonts =="; python3 tools/embed_fonts.py App/web/index.html
echo "== Tools =="; brew install xcodegen librsvg
echo "== Icon =="
rsvg-convert -w 1024 -h 1024 icon.svg -o "$RUNNER_TEMP/icon.png"
sips -s format jpeg -s formatOptions 100 "$RUNNER_TEMP/icon.png" --out "$RUNNER_TEMP/icon.jpg"
sips -s format png "$RUNNER_TEMP/icon.jpg" --out App/Assets.xcassets/AppIcon.appiconset/AppIcon.png
echo "== Project =="; xcodegen generate

KEY="$HOME/private_keys/AuthKey_${ASC_KEY_ID}.p8"
mkdir -p "$HOME/private_keys"; printf '%s\n' "$ASC_KEY_P8" > "$KEY"
trap 'rm -rf "$HOME/private_keys"' EXIT
AUTH=(-allowProvisioningUpdates -authenticationKeyPath "$KEY" -authenticationKeyID "$ASC_KEY_ID" -authenticationKeyIssuerID "$ASC_ISSUER_ID")

echo "== Build =="
xcodebuild archive -project LanguageQuest.xcodeproj -scheme LanguageQuest -configuration Release \
  -destination 'generic/platform=iOS' -archivePath "$RUNNER_TEMP/LanguageQuest.xcarchive" "${AUTH[@]}"
echo "== Sign and upload =="
xcodebuild -exportArchive -archivePath "$RUNNER_TEMP/LanguageQuest.xcarchive" \
  -exportOptionsPlist ExportOptions.plist -exportPath "$RUNNER_TEMP/export" "${AUTH[@]}"
echo "Done. The build will appear in App Store Connect under TestFlight in a few minutes."

import SwiftUI
import UIKit
import WebKit
import AVFoundation
import StoreKit

// Language Quest: the whole game is one web page stored inside the app (App/web/index.html).
// This shell shows it full screen. It works with no internet connection and makes no network calls.
//
// Version 1.1 adds a small bridge between the page and the app (see src/native.js in the game):
//   - a second copy of the player's progress, kept as a file in the app's own storage, in case iOS clears web storage
//   - haptics, a share sheet for the progress picture, and Apple's review prompt
// The page talks to the app through one message channel named "lq". Every message is optional:
// a page that never sends one behaves exactly like version 1.0.

@main
struct LanguageQuestApp: App {
    init() {
        // Game sound mixes with other audio and follows the ring/silent switch.
        try? AVAudioSession.sharedInstance().setCategory(.ambient, options: [.mixWithOthers])
        try? AVAudioSession.sharedInstance().setActive(true)
    }
    var body: some Scene {
        WindowGroup {
            ZStack {
                // The same dark blue as the game's own background (#0d1a29) and the launch screen.
                Color(red: 13.0 / 255.0, green: 26.0 / 255.0, blue: 41.0 / 255.0).ignoresSafeArea()
                // Edge to edge: the page itself keeps buttons clear of the notch and the home bar
                // (viewport-fit=cover and env(safe-area-inset-*) in its CSS).
                GameView().ignoresSafeArea()
            }
            .statusBarHidden(true)
        }
    }
}

// MARK: - The player's progress, kept as a file

/// Keeps the newest good copy of the saved game ("save.json") and one older copy ("save-previous.json")
/// in Application Support/LanguageQuest. Files only: no UserDefaults, no iCloud, no network.
final class SaveStore {      // plain file reads and writes; only ever used from the main thread by the Coordinator
    private static let currentName = "save.json"
    private static let previousName = "save-previous.json"
    private static let reviewName = "review-asked.txt"
    private static let sizeLimit = 4_000_000

    private let folder: URL?
    private var keptPreviousThisLaunch = false
    private var lastWritten: String?

    init() {
        let fm = FileManager.default
        var made: URL? = nil
        if let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first {
            let dir = base.appendingPathComponent("LanguageQuest", isDirectory: true)
            do {
                try fm.createDirectory(at: dir, withIntermediateDirectories: true, attributes: nil)
                made = dir
            } catch {
                made = nil
            }
        }
        folder = made
    }

    // How far along a saved game is. The same rule as saveRank() in the game's core2.js:
    // first the number of deliberate erases (only the Erase button raises it), then how full the save is.
    // It reads only the oldest fields (stars, mi, plays, sparks, rst) and puts up with anything else.
    struct Rank {
        let resets: Double
        let score: Double
        func isBehind(_ other: Rank) -> Bool {
            if resets != other.resets { return resets < other.resets }
            return score < other.score
        }
    }

    private static func count(_ value: Any?) -> Double {
        guard let number = value as? NSNumber else { return 0 }
        if String(cString: number.objCType) == "c" { return 0 }      // true / false is not a number
        let d = number.doubleValue
        if !d.isFinite || d <= 0 { return 0 }
        return d.rounded(.down)
    }

    static func rank(of save: [String: Any]) -> Rank {
        var progress: Double = 0
        if let stars = save["stars"] as? [Any] {
            var seen = 0
            for item in stars {
                if seen >= 500 { break }
                seen += 1
                let value = min(3.0, count(item))
                if value > 0 { progress += 10.0 + value }             // 10 for a finished trail + its stars
            }
        }
        if let words = save["mi"] as? [String: Any] {
            progress += Double(min(5000, words.count))                // 1 for each word met
        }
        let extra = min(999_999_999.0, count(save["plays"]) + count(save["sparks"]))
        return Rank(resets: count(save["rst"]), score: progress * 1_000_000_000.0 + extra)
    }

    static func parse(_ text: String) -> [String: Any]? {
        guard let data = text.data(using: .utf8) else { return nil }
        guard let object = try? JSONSerialization.jsonObject(with: data, options: []) else { return nil }
        return object as? [String: Any]
    }

    /// The text of a stored copy, or nil if it is missing, too big or not a saved game.
    private func read(_ name: String) -> String? {
        guard let folder = folder else { return nil }
        guard let data = try? Data(contentsOf: folder.appendingPathComponent(name)) else { return nil }
        if data.count < 2 || data.count > SaveStore.sizeLimit { return nil }
        guard let text = String(data: data, encoding: .utf8) else { return nil }
        if SaveStore.parse(text) == nil { return nil }
        return text
    }

    /// The copy to hand to the page: the newest one, or the older one if the newest is damaged.
    func best() -> String? {
        if let current = read(SaveStore.currentName) { return current }
        return read(SaveStore.previousName)
    }

    /// Stores a saved game sent by the page. Never replaces a fuller copy with an emptier one,
    /// unless the player pressed Erase (the save's erase count went up).
    func store(_ json: String) {
        guard let folder = folder else { return }
        if json == lastWritten { return }
        if json.utf8.count > SaveStore.sizeLimit { return }
        guard let incoming = SaveStore.parse(json) else { return }
        guard let data = json.data(using: .utf8) else { return }
        let fm = FileManager.default
        let currentURL = folder.appendingPathComponent(SaveStore.currentName)
        let previousURL = folder.appendingPathComponent(SaveStore.previousName)
        let incomingRank = SaveStore.rank(of: incoming)

        if let heldText = read(SaveStore.currentName), let held = SaveStore.parse(heldText) {
            let heldRank = SaveStore.rank(of: held)
            if incomingRank.isBehind(heldRank) { return }
            if incomingRank.resets > heldRank.resets {
                // The player erased their progress on purpose: do not keep the old game around.
                try? fm.removeItem(at: previousURL)
                keptPreviousThisLaunch = true
            } else if !keptPreviousThisLaunch {
                // Once each time the app is opened: keep how things stood at the end of last time.
                if let heldData = heldText.data(using: .utf8) {
                    try? heldData.write(to: previousURL, options: .atomic)
                }
                keptPreviousThisLaunch = true
            }
        } else if let olderText = read(SaveStore.previousName), let older = SaveStore.parse(olderText) {
            // The newest copy is missing or damaged; the older one is all we hold. Same rule.
            if incomingRank.isBehind(SaveStore.rank(of: older)) { return }
        }

        do {
            try data.write(to: currentURL, options: .atomic)
            lastWritten = json
        } catch {
            lastWritten = nil
        }
    }

    /// Has Apple's review prompt been asked for on this install? (If the record cannot be kept, never ask.)
    var reviewAsked: Bool {
        guard let folder = folder else { return true }
        return FileManager.default.fileExists(atPath: folder.appendingPathComponent(SaveStore.reviewName).path)
    }

    /// Returns true if the record was written.
    func markReviewAsked() -> Bool {
        guard let folder = folder else { return false }
        guard let data = "asked".data(using: .utf8) else { return false }
        do {
            try data.write(to: folder.appendingPathComponent(SaveStore.reviewName), options: .atomic)
            return true
        } catch {
            return false
        }
    }
}

// MARK: - The web view

struct GameView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let night = UIColor(red: 13.0 / 255.0, green: 26.0 / 255.0, blue: 41.0 / 255.0, alpha: 1)
        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.websiteDataStore = .default()          // keeps the player's progress between launches
        cfg.userContentController.add(context.coordinator, name: Coordinator.channel)
        let wv = WKWebView(frame: .zero, configuration: cfg)
        wv.isOpaque = false
        wv.backgroundColor = night
        wv.scrollView.backgroundColor = night
        wv.scrollView.bounces = false
        wv.scrollView.contentInsetAdjustmentBehavior = .never
        wv.allowsLinkPreview = false
        wv.allowsBackForwardNavigationGestures = false
        wv.navigationDelegate = context.coordinator
        wv.uiDelegate = context.coordinator
        context.coordinator.attach(wv)
        context.coordinator.loadGame()
        return wv
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    @MainActor
    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        static let channel = "lq"

        private weak var webView: WKWebView?
        private let store = SaveStore()
        private let lightTap = UIImpactFeedbackGenerator(style: .light)
        private let softTap = UIImpactFeedbackGenerator(style: .soft)
        private let notice = UINotificationFeedbackGenerator()

        func attach(_ wv: WKWebView) {
            webView = wv
            NotificationCenter.default.addObserver(self, selector: #selector(appWillResignActive),
                                                   name: UIApplication.willResignActiveNotification, object: nil)
        }

        // MARK: Loading the page

        /// What the page is told before any of its own script runs: that the bridge exists,
        /// and the app's copy of the saved game if there is one.
        private func startScript() -> WKUserScript {
            var js = "window.__LQ_NATIVE={v:1,caps:{backup:1,haptic:1,share:1,review:1}};"
            if let saved = store.best(),
               let data = try? JSONSerialization.data(withJSONObject: [saved], options: []),
               let text = String(data: data, encoding: .utf8) {
                // `text` is a JSON array holding one string, e.g. ["{\"stars\":[3]}"], which is also valid JavaScript.
                let safe = text.replacingOccurrences(of: "\u{2028}", with: "\\u2028")
                    .replacingOccurrences(of: "\u{2029}", with: "\\u2029")
                js += "window.__LQ_BACKUP=" + safe + "[0];"
            }
            return WKUserScript(source: js, injectionTime: .atDocumentStart, forMainFrameOnly: true)
        }

        /// Loads the game from the start, with a fresh copy of the saved game for the page.
        func loadGame() {
            guard let wv = webView else { return }
            let scripts = wv.configuration.userContentController
            scripts.removeAllUserScripts()
            scripts.addUserScript(startScript())
            if let url = Bundle.main.url(forResource: "index", withExtension: "html") {
                wv.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
            } else {
                wv.loadHTMLString("<body style='background:#0d1a29;color:#fff;font:20px -apple-system;padding:40px'>The game file is missing from this build.</body>", baseURL: nil)
            }
        }

        // MARK: Messages from the page

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == Coordinator.channel, message.frameInfo.isMainFrame else { return }
            guard let body = message.body as? [String: Any], let type = body["t"] as? String else { return }
            switch type {
            case "backup":
                if let json = body["json"] as? String { store.store(json) }
            case "haptic":
                if let kind = body["k"] as? String { haptic(kind) }
            case "share":
                if let png = body["png"] as? String { share(png, rect: body["rect"] as? [String: Any]) }
            case "review":
                askForReview()
            case "reload":
                loadGame()
            default:
                break
            }
        }

        // MARK: Haptics

        private func haptic(_ kind: String) {
            if UIAccessibility.isReduceMotionEnabled { return }
            switch kind {
            case "ok":
                lightTap.impactOccurred()
            case "no":
                softTap.impactOccurred(intensity: 0.8)
            case "bump":
                softTap.impactOccurred()
            case "tick":
                lightTap.impactOccurred(intensity: 0.5)
            case "spark":
                lightTap.impactOccurred(intensity: 0.35)
            case "done":
                notice.notificationOccurred(.success)
            default:
                break
            }
        }

        // MARK: Sharing the progress picture

        private func topController() -> UIViewController? {
            var top = webView?.window?.rootViewController
            while let next = top?.presentedViewController { top = next }
            return top
        }

        private func cgNumber(_ value: Any?) -> CGFloat? {
            guard let number = value as? NSNumber else { return nil }
            let d = number.doubleValue
            if !d.isFinite { return nil }
            return CGFloat(d)
        }

        /// Where the share sheet's arrow points on iPad: the Share button, or the middle of the screen.
        private func anchor(_ rect: [String: Any]?, in view: UIView) -> CGRect {
            let bounds = view.bounds
            let middle = CGRect(x: bounds.midX - 1, y: bounds.midY - 1, width: 2, height: 2)
            guard let rect = rect,
                  let x = cgNumber(rect["x"]), let y = cgNumber(rect["y"]),
                  let w = cgNumber(rect["w"]), let h = cgNumber(rect["h"]) else { return middle }
            if w < 1 || h < 1 { return middle }
            let made = CGRect(x: x, y: y, width: w, height: h)
            if !bounds.contains(made) { return middle }
            return made
        }

        private func share(_ pngBase64: String, rect: [String: Any]?) {
            guard let wv = webView, wv.window != nil else { return }
            if pngBase64.utf8.count > 16_000_000 { return }
            guard let data = Data(base64Encoded: pngBase64), data.count > 100 else { return }
            if UIImage(data: data) == nil { return }                  // only ever a picture
            guard let host = topController() else { return }
            if host is UIActivityViewController { return }            // a share sheet is already open
            if host.isBeingDismissed || host.isBeingPresented { return }
            let file = FileManager.default.temporaryDirectory.appendingPathComponent("Language Quest.png")
            do {
                try data.write(to: file, options: .atomic)
            } catch {
                return
            }
            let sheet = UIActivityViewController(activityItems: [file], applicationActivities: nil)
            if let popover = sheet.popoverPresentationController {    // iPad shows the sheet as a popover and needs an anchor
                popover.sourceView = wv
                popover.sourceRect = anchor(rect, in: wv)
            }
            host.present(sheet, animated: true, completion: nil)
        }

        // MARK: Review prompt

        /// Apple's standard prompt. At most once per install; Apple decides whether it is really shown.
        private func askForReview() {
            if store.reviewAsked { return }
            guard let wv = webView, let scene = wv.window?.windowScene else { return }
            if scene.activationState != .foregroundActive { return }
            if wv.window?.rootViewController?.presentedViewController != nil { return }
            if !store.markReviewAsked() { return }
            SKStoreReviewController.requestReview(in: scene)
        }

        // MARK: App life cycle

        /// The app is no longer in front (app switcher, Control Centre, a call, the lock button):
        /// pause a trail that is running and store the progress now.
        @objc private func appWillResignActive() {
            webView?.evaluateJavaScript("try{if(window.Native&&window.Native.onInactive)window.Native.onInactive()}catch(e){}", completionHandler: nil)
        }

        // MARK: Links and recovery

        // Web links (the sources on the About page) open in Safari, not inside the game.
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if let url = navigationAction.request.url, let scheme = url.scheme?.lowercased(),
               scheme == "http" || scheme == "https" || scheme == "mailto" || scheme == "tel" {
                if navigationAction.navigationType == .linkActivated || navigationAction.targetFrame == nil {
                    UIApplication.shared.open(url)
                }
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = navigationAction.request.url { UIApplication.shared.open(url) }
            return nil
        }
        // If iOS stops the web content to save memory, start the page again with the app's copy of the progress.
        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { loadGame() }
    }
}

#!/usr/bin/env python3
"""Put the game's two web fonts inside index.html so the app needs no internet.
Usage: embed_fonts.py path/to/index.html   (safe to run twice; leaves the file alone if anything fails)"""
import base64, re, sys, urllib.request

UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"

def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()

def main(path):
    html = open(path, encoding="utf-8").read()
    m = re.search(r'<link[^>]+href="(https://fonts\.googleapis\.com/css2[^"]+)"[^>]*>', html)
    if not m:
        print("fonts: no Google Fonts link found (already embedded?)"); return 0
    css = get(m.group(1).replace("&amp;", "&")).decode("utf-8")
    urls = sorted(set(re.findall(r"url\((https://[^)]+)\)", css)))
    for u in urls:
        data = get(u)
        css = css.replace(u, "data:font/woff2;base64," + base64.b64encode(data).decode("ascii"))
    out = html.replace(m.group(0), "<style>" + css + "</style>")
    out = re.sub(r'<link[^>]+rel="preconnect"[^>]*>\s*', "", out)
    open(path, "w", encoding="utf-8").write(out)
    print("fonts: embedded %d font files, page is now %d KB" % (len(urls), len(out.encode("utf-8")) // 1024)); return 0

if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1]))
    except Exception as e:                      # never fail the build over fonts: the game falls back to system fonts
        print("fonts: skipped (%s)" % e); sys.exit(0)
